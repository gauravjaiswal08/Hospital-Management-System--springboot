package com.company.varnaa;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;


public interface invoiceRepository extends JpaRepository<invoice,Integer> {

}